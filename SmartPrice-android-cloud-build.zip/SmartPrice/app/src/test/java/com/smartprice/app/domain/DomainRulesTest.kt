package com.smartprice.app.domain

import com.smartprice.app.data.Product
import org.junit.Assert.*
import org.junit.Test

class DomainRulesTest {
    private val rice = Product("RICE-5KG", "Rice 5kg", costPaise = 40000, sellingPaise = 50000, minimumPaise = 45000, stock = 10)
    private val valid = ProductInput("Rice 5kg", "RICE-5KG", "400", "500", "450", "10")

    @Test fun grossProfitIsOfferMinusCost() =
        assertEquals(4000L, BargainCalculator.evaluate(rice, 44000).grossProfitPaise)

    @Test fun offerBelowMinimumWarns() =
        assertEquals(OfferStatus.BELOW_MINIMUM, BargainCalculator.evaluate(rice, 44999).status)

    @Test fun offerAtMinimumIsOk() =
        assertEquals(OfferStatus.GOOD, BargainCalculator.evaluate(rice, 45000).status)

    @Test fun offerBelowCostIsLoss() {
        val r = BargainCalculator.evaluate(rice, 39000)
        assertEquals(OfferStatus.LOSS, r.status); assertEquals(-1000L, r.grossProfitPaise)
    }

    @Test fun negativePriceRejected() =
        assertTrue(ProductValidator.validate(valid.copy(cost = "-5")).errors.containsKey("cost"))

    @Test fun negativeStockRejected() =
        assertTrue(ProductValidator.validate(valid.copy(stock = "-1")).errors.containsKey("stock"))

    @Test fun minimumAboveSellingRejected() =
        assertTrue(ProductValidator.validate(valid.copy(minimum = "600")).errors.containsKey("minimum"))

    @Test fun validProductParsesToPaise() {
        val p = ProductValidator.validate(valid.copy(cost = "400.5")).product!!
        assertEquals(40050L, p.costPaise)
    }

    @Test fun stockCannotGoNegative() = assertNull(StockRules.adjust(0, -1))

    @Test fun lowStockAtFiveOrFewer() { assertTrue(StockRules.isLow(5)); assertFalse(StockRules.isLow(6)) }

    @Test fun qrHoldsOnlyProductId() {
        assertEquals("SMARTPRICE:RICE-5KG", QrPayload.encode("RICE-5KG"))
        assertEquals("RICE-5KG", QrPayload.decode("SMARTPRICE:RICE-5KG"))
    }
}
