package com.smartprice.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

/** Plain, unencrypted local SQLite database. For demonstration only. */
@Database(entities = [Product::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
}
