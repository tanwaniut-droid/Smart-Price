package com.smartprice.app.domain

object Money {
    private val pattern = Regex("^\\d{1,9}(\\.\\d{1,2})?$")

    /** Parses "120", "120.5", "120.50" into paise. Returns null for invalid or negative input. */
    fun parse(input: String): Long? {
        val t = input.trim().replace(",", "")
        if (!pattern.matches(t)) return null
        val parts = t.split(".")
        val rupees = parts[0].toLong()
        val paise = if (parts.size == 2) parts[1].padEnd(2, '0').toLong() else 0L
        return rupees * 100 + paise
    }

    fun format(paise: Long): String {
        val sign = if (paise < 0) "-" else ""
        val abs = kotlin.math.abs(paise)
        return "$sign₹${abs / 100}.${(abs % 100).toString().padStart(2, '0')}"
    }

    fun toInput(paise: Long): String = "${paise / 100}.${(paise % 100).toString().padStart(2, '0')}"
}
