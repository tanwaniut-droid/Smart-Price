package com.smartprice.app.domain

import com.smartprice.app.data.Product

data class ProductInput(
    val name: String = "",
    val productId: String = "",
    val cost: String = "",
    val selling: String = "",
    val minimum: String = "",
    val stock: String = "",
)

data class ValidationResult(val product: Product?, val errors: Map<String, String>)

object ProductValidator {
    const val MAX_STOCK = 1_000_000
    private val idPattern = Regex("^[A-Za-z0-9_-]{1,32}$")

    fun validate(input: ProductInput): ValidationResult {
        val e = mutableMapOf<String, String>()
        val name = input.name.trim()
        val id = input.productId.trim()

        when {
            name.isEmpty() -> e["name"] = "Enter a product name."
            name.length > 60 -> e["name"] = "Name must be 60 characters or fewer."
        }
        when {
            id.isEmpty() -> e["productId"] = "Enter a unique product ID."
            !idPattern.matches(id) -> e["productId"] = "Use 1–32 letters, numbers, - or _ (no spaces)."
        }
        val cost = money(input.cost, "cost", "cost price", e)
        val sell = money(input.selling, "selling", "selling price", e)
        val min = money(input.minimum, "minimum", "minimum price", e)

        if (sell != null && sell == 0L) e["selling"] = "Selling price must be more than ₹0."
        if (sell != null && min != null && min > sell) e["minimum"] = "Minimum price cannot be higher than the selling price."

        val stockText = input.stock.trim()
        val stock = stockText.toIntOrNull()
        when {
            stockText.isEmpty() -> e["stock"] = "Enter the stock quantity."
            stockText.startsWith("-") -> e["stock"] = "Stock cannot be negative."
            stock == null -> e["stock"] = "Stock must be a whole number."
            stock > MAX_STOCK -> e["stock"] = "Stock cannot exceed $MAX_STOCK."
        }

        if (e.isNotEmpty()) return ValidationResult(null, e)
        return ValidationResult(Product(id, name, cost!!, sell!!, min!!, stock!!), emptyMap())
    }

    private fun money(raw: String, key: String, label: String, e: MutableMap<String, String>): Long? {
        val t = raw.trim()
        if (t.isEmpty()) { e[key] = "Enter the $label."; return null }
        if (t.startsWith("-")) { e[key] = "The $label cannot be negative."; return null }
        return Money.parse(t) ?: run { e[key] = "Enter a valid amount like 120 or 120.50."; null }
    }

    /** Soft warnings that do not block saving. */
    fun warnings(p: Product): List<String> = buildList {
        if (p.sellingPaise < p.costPaise) add("Selling price is below cost price — you will make a loss.")
        if (p.minimumPaise < p.costPaise) add("Minimum price is below cost price.")
    }
}
