package com.smartprice.app.domain

/** QR codes contain ONLY the product ID — never prices or other private data. */
object QrPayload {
    private const val PREFIX = "SMARTPRICE:"
    fun encode(productId: String) = PREFIX + productId
    fun decode(raw: String): String? {
        val t = raw.trim()
        val id = if (t.startsWith(PREFIX)) t.removePrefix(PREFIX) else t
        return id.takeIf { Regex("^[A-Za-z0-9_-]{1,32}$").matches(it) }
    }
}
