package com.smartprice.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartprice.app.domain.StockRules
import com.smartprice.app.ui.SmartPriceViewModel
import kotlinx.coroutines.launch

@Composable
fun StockScreen(vm: SmartPriceViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val products by vm.products.collectAsStateWithLifecycle()
    val sorted = remember(products) { products.sortedBy { it.stock } }
    val low = products.count { StockRules.isLow(it.stock) || StockRules.isOut(it.stock) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    SpScaffold("Stock Management", onBack) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                if (low > 0) Banner("⚠ $low product(s) at or below ${StockRules.LOW_STOCK_THRESHOLD} units. Restock soon.",
                    MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.error)
                else if (products.isNotEmpty()) Banner("All products have healthy stock.",
                    MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                else Text("No products yet.")
            }
            error?.let { item { Banner(it, MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.error) } }
            items(sorted, key = { it.productId }) { p ->
                ElevatedCard(onClick = { onOpen(p.productId) }, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            StockChip(p.stock)
                        }
                        FilledTonalIconButton(onClick = { scope.launch { error = vm.adjustStock(p, -1) } }, enabled = p.stock > 0) {
                            Icon(Icons.Filled.Remove, "Remove one")
                        }
                        Text("${p.stock}", Modifier.padding(horizontal = 8.dp), style = MaterialTheme.typography.titleLarge)
                        FilledTonalIconButton(onClick = { scope.launch { error = vm.adjustStock(p, 1) } }) {
                            Icon(Icons.Filled.Add, "Add one")
                        }
                    }
                }
            }
        }
    }
}
