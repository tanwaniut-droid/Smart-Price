package com.smartprice.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.smartprice.app.ui.SmartPriceRoot
import com.smartprice.app.ui.theme.SmartPriceTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as SmartPriceApplication).container
        setContent { SmartPriceTheme { SmartPriceRoot(container) } }
    }
}
