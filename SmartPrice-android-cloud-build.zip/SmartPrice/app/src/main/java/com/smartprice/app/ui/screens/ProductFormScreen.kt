package com.smartprice.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.smartprice.app.domain.Money
import com.smartprice.app.domain.ProductInput
import com.smartprice.app.domain.ProductValidator
import kotlinx.coroutines.launch

@Composable
fun ProductFormScreen(vm: com.smartprice.app.ui.SmartPriceViewModel, editId: String?, onBack: () -> Unit, onSaved: () -> Unit) {
    var input by remember { mutableStateOf(ProductInput()) }
    var errors by remember { mutableStateOf(emptyMap<String, String>()) }
    var formError by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf(editId == null) }
    var saving by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(editId) {
        if (editId != null) {
            val p = vm.find(editId)
            if (p == null) formError = "This product no longer exists."
            else input = ProductInput(p.name, p.productId, Money.toInput(p.costPaise), Money.toInput(p.sellingPaise), Money.toInput(p.minimumPaise), p.stock.toString())
            loaded = true
        }
    }

    SpScaffold(title = if (editId == null) "Add Product" else "Edit Product", onBack = onBack) { pad ->
        if (!loaded) { Box(Modifier.padding(pad).fillMaxSize()) { CircularProgressIndicator(Modifier.padding(32.dp)) }; return@SpScaffold }
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Field("Product name", input.name, errors["name"]) { input = input.copy(name = it) }
            Field("Unique product ID", input.productId, errors["productId"], enabled = editId == null,
                help = if (editId != null) "Product ID cannot be changed (it is printed on the QR code)." else "Example: RICE-5KG") { input = input.copy(productId = it) }
            Field("Cost price (₹)", input.cost, errors["cost"], KeyboardType.Decimal) { input = input.copy(cost = it) }
            Field("Selling price (₹)", input.selling, errors["selling"], KeyboardType.Decimal) { input = input.copy(selling = it) }
            Field("Minimum selling price (₹)", input.minimum, errors["minimum"], KeyboardType.Decimal) { input = input.copy(minimum = it) }
            Field("Stock quantity", input.stock, errors["stock"], KeyboardType.Number) { input = input.copy(stock = it) }

            formError?.let { Banner(it, MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.error) }

            Button(
                enabled = !saving,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                onClick = {
                    formError = null
                    val result = ProductValidator.validate(input)
                    errors = result.errors
                    val product = result.product ?: run { formError = "Please fix the highlighted fields."; return@Button }
                    saving = true
                    scope.launch {
                        val r = if (editId == null) vm.add(product) else vm.update(product)
                        saving = false
                        r.onSuccess { onSaved() }.onFailure {
                            formError = it.message ?: "Could not save product."
                            if (it is com.smartprice.app.data.DuplicateProductIdException) errors = errors + ("productId" to "This ID is already used.")
                        }
                    }
                },
            ) { Text(if (editId == null) "Save product" else "Save changes") }

            ProductValidator.validate(input).product?.let { p ->
                ProductValidator.warnings(p).forEach {
                    Banner("Note: $it", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }
    }
}

@Composable
private fun Field(
    label: String, value: String, error: String?, keyboard: KeyboardType = KeyboardType.Text,
    enabled: Boolean = true, help: String? = null, onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, enabled = enabled,
        isError = error != null, singleLine = true,
        supportingText = { (error ?: help)?.let { Text(it) } },
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        modifier = Modifier.fillMaxWidth(),
    )
}
