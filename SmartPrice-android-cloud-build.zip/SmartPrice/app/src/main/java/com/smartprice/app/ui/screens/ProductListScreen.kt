package com.smartprice.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartprice.app.data.Product
import com.smartprice.app.domain.Money
import com.smartprice.app.domain.StockRules
import com.smartprice.app.ui.SmartPriceViewModel

@Composable
fun ProductListScreen(vm: SmartPriceViewModel, onBack: () -> Unit, onOpen: (String) -> Unit, onAdd: () -> Unit) {
    val products by vm.products.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    val filtered = remember(products, query) {
        val q = query.trim()
        if (q.isEmpty()) products else products.filter { it.name.contains(q, true) || it.productId.contains(q, true) }
    }
    SpScaffold("Products", onBack, fab = {
        FloatingActionButton(onClick = onAdd, containerColor = MaterialTheme.colorScheme.secondary) { Icon(Icons.Filled.Add, "Add product") }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {
            OutlinedTextField(query, { query = it.take(60) }, Modifier.fillMaxWidth().padding(vertical = 12.dp),
                placeholder = { Text("Search by name or ID") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true)
            if (filtered.isEmpty()) {
                Text(if (products.isEmpty()) "No products yet. Tap + to add your first product." else "No product matches \"$query\".",
                    Modifier.padding(24.dp))
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 88.dp)) {
                items(filtered, key = { it.productId }) { ProductRow(it) { onOpen(it.productId) } }
            }
        }
    }
}

@Composable
fun ProductRow(p: Product, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("ID: ${p.productId}", style = MaterialTheme.typography.bodySmall)
                Text("Sell ${Money.format(p.sellingPaise)}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
            StockChip(p.stock)
        }
    }
}

@Composable
fun StockChip(stock: Int) {
    val (bg, fg, label) = when {
        StockRules.isOut(stock) -> Triple(MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.error, "Out of stock")
        StockRules.isLow(stock) -> Triple(MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer, "Low: $stock")
        else -> Triple(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer, "Stock: $stock")
    }
    Surface(color = bg, contentColor = fg, shape = RoundedCornerShape(50)) {
        Text(label, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge)
    }
}
