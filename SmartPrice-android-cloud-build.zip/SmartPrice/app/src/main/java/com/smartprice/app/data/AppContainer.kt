package com.smartprice.app.data

import android.content.Context
import androidx.room.Room

/** Simple manual dependency container. Replace the repository here when adding a backend. */
class AppContainer(context: Context) {
    private val db = Room.databaseBuilder(context, AppDatabase::class.java, "smartprice-demo.db").build()
    val productRepository: ProductRepository = LocalProductRepository(db.productDao())
}
