package com.smartprice.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartprice.app.domain.Money
import com.smartprice.app.domain.QrPayload
import com.smartprice.app.ui.SmartPriceViewModel
import com.smartprice.app.util.QrGenerator

@Composable
fun ProductDetailScreen(vm: SmartPriceViewModel, id: String, onBack: () -> Unit, onEdit: (String) -> Unit, onBargain: (String) -> Unit) {
    val products by vm.products.collectAsStateWithLifecycle()
    val p = products.firstOrNull { it.productId == id }
    var confirmDelete by remember { mutableStateOf(false) }
    val qr = remember(id) { QrGenerator.generate(QrPayload.encode(id)).asImageBitmap() }

    SpScaffold(p?.name ?: "Product", onBack, actions = {
        if (p != null) {
            IconButton(onClick = { onEdit(id) }) { Icon(Icons.Filled.Edit, "Edit") }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Delete") }
        }
    }) { pad ->
        if (p == null) { Text("Product \"$id\" not found.", Modifier.padding(pad).padding(24.dp)); return@SpScaffold }
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ElevatedCard(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    InfoRow("Product ID", p.productId)
                    InfoRow("Selling price", Money.format(p.sellingPaise))
                    InfoRow("Cost price", Money.format(p.costPaise))
                    InfoRow("Minimum price", Money.format(p.minimumPaise))
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("Stock", Modifier.weight(1f)); StockChip(p.stock) }
                }
            }
            Button(onClick = { onBargain(id) }, Modifier.fillMaxWidth().height(52.dp)) { Text("Check a customer offer") }
            ElevatedCard(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Product QR code", fontWeight = FontWeight.Bold)
                    Image(qr, "QR code for ${p.productId}", Modifier.size(220.dp).padding(8.dp))
                    Text("Contains only the product ID — no prices.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
    if (confirmDelete && p != null) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete ${p.name}?") },
        text = { Text("This removes the product from this phone. It cannot be undone.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete(id); onBack() }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
    )
}

@Composable
private fun InfoRow(label: String, value: String) = Row {
    Text(label, Modifier.weight(1f))
    Text(value, fontWeight = FontWeight.SemiBold)
}
