package com.smartprice.app.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.smartprice.app.data.AppContainer
import com.smartprice.app.ui.screens.*

object Routes {
    const val HOME = "home"; const val ADD = "add"; const val LIST = "list"; const val SCAN = "scan"
    const val STOCK = "stock"; const val BARGAIN = "bargain?id={id}"; const val EDIT = "edit/{id}"; const val DETAIL = "detail/{id}"
    fun bargain(id: String? = null) = if (id == null) "bargain" else "bargain?id=$id"
    fun edit(id: String) = "edit/$id"
    fun detail(id: String) = "detail/$id"
}

@Composable
fun SmartPriceRoot(container: AppContainer) {
    val nav = rememberNavController()
    val vm: SmartPriceViewModel = viewModel(factory = SmartPriceViewModel.Factory(container.productRepository))
    val back: () -> Unit = { nav.popBackStack() }
    NavHost(nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) { HomeScreen(onNavigate = { nav.navigate(it) }, vm = vm) }
        composable(Routes.ADD) { ProductFormScreen(vm, null, onBack = back, onSaved = back) }
        composable(Routes.EDIT, listOf(navArgument("id") { type = NavType.StringType })) {
            ProductFormScreen(vm, it.arguments?.getString("id"), onBack = back, onSaved = back)
        }
        composable(Routes.LIST) {
            ProductListScreen(vm, onBack = back, onOpen = { id -> nav.navigate(Routes.detail(id)) }, onAdd = { nav.navigate(Routes.ADD) })
        }
        composable(Routes.DETAIL, listOf(navArgument("id") { type = NavType.StringType })) {
            ProductDetailScreen(vm, it.arguments?.getString("id").orEmpty(), onBack = back,
                onEdit = { id -> nav.navigate(Routes.edit(id)) },
                onBargain = { id -> nav.navigate(Routes.bargain(id)) })
        }
        composable(Routes.BARGAIN, listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })) {
            BargainScreen(vm, it.arguments?.getString("id"), onBack = back)
        }
        composable(Routes.SCAN) {
            ScanScreen(vm, onBack = back, onFound = { id ->
                nav.navigate(Routes.detail(id)) { popUpTo(Routes.SCAN) { inclusive = true } }
            })
        }
        composable(Routes.STOCK) { StockScreen(vm, onBack = back, onOpen = { nav.navigate(Routes.detail(it)) }) }
    }
}
