package com.smartprice.app.data

import android.database.sqlite.SQLiteConstraintException
import kotlinx.coroutines.flow.Flow

/**
 * The UI only talks to this interface. To add login + shared storage later,
 * write e.g. RemoteProductRepository (authenticated API) and swap it in AppContainer.
 */
interface ProductRepository {
    fun observeProducts(): Flow<List<Product>>
    suspend fun findById(id: String): Product?
    suspend fun add(product: Product): Result<Unit>
    suspend fun update(product: Product): Result<Unit>
    suspend fun delete(id: String)
}

class DuplicateProductIdException(id: String) : Exception("A product with ID \"$id\" already exists.")

class LocalProductRepository(private val dao: ProductDao) : ProductRepository {
    override fun observeProducts() = dao.observeAll()
    override suspend fun findById(id: String) = dao.findById(id)
    override suspend fun add(product: Product): Result<Unit> = try {
        dao.insert(product); Result.success(Unit)
    } catch (e: SQLiteConstraintException) {
        Result.failure(DuplicateProductIdException(product.productId))
    }
    override suspend fun update(product: Product): Result<Unit> =
        if (dao.update(product.copy(updatedAt = System.currentTimeMillis())) == 1) Result.success(Unit)
        else Result.failure(IllegalStateException("Product not found."))
    override suspend fun delete(id: String) = dao.delete(id)
}
