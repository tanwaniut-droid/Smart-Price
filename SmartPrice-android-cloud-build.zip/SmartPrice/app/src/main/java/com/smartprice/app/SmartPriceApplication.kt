package com.smartprice.app

import android.app.Application
import com.smartprice.app.data.AppContainer

class SmartPriceApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
