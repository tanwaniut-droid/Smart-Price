package com.smartprice.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartprice.app.domain.StockRules
import com.smartprice.app.ui.Routes
import com.smartprice.app.ui.SmartPriceViewModel

private data class HomeAction(val label: String, val hint: String, val icon: ImageVector, val route: String)

@Composable
fun HomeScreen(onNavigate: (String) -> Unit, vm: SmartPriceViewModel) {
    val products by vm.products.collectAsStateWithLifecycle()
    val lowCount = products.count { StockRules.isLow(it.stock) || StockRules.isOut(it.stock) }
    val actions = listOf(
        HomeAction("Add Product", "New item with prices", Icons.Filled.AddBox, Routes.ADD),
        HomeAction("View Products", "${products.size} saved", Icons.Filled.Inventory2, Routes.LIST),
        HomeAction("Scan QR Code", "Find a product fast", Icons.Filled.QrCodeScanner, Routes.SCAN),
        HomeAction("Bargaining Calculator", "Check a customer offer", Icons.Filled.Calculate, Routes.bargain()),
        HomeAction("Stock Management", if (lowCount > 0) "$lowCount need restock" else "All stocked", Icons.Filled.Warehouse, Routes.STOCK),
    )
    SpScaffold(title = "SmartPrice", onBack = null) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Namaste! What would you like to do?", style = MaterialTheme.typography.titleMedium)
            if (lowCount > 0) Banner("⚠ $lowCount product(s) are low or out of stock.",
                MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.error)
            actions.forEach { a ->
                ElevatedCard(
                    onClick = { onNavigate(a.route) },
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                            Icon(a.icon, null, Modifier.padding(12.dp).size(28.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(a.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(a.hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                        }
                    }
                }
            }
            DemoNotice()
        }
    }
}
