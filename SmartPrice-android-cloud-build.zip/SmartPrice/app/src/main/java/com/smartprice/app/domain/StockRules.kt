package com.smartprice.app.domain

object StockRules {
    const val LOW_STOCK_THRESHOLD = 5
    fun isOut(stock: Int) = stock <= 0
    fun isLow(stock: Int) = stock in 1..LOW_STOCK_THRESHOLD

    /** Returns new stock or null if the change would make it negative / too large. */
    fun adjust(current: Int, delta: Int): Int? {
        val next = current.toLong() + delta
        return if (next < 0 || next > ProductValidator.MAX_STOCK) null else next.toInt()
    }
}
