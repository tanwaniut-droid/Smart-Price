package com.smartprice.app.domain

import com.smartprice.app.data.Product

enum class OfferStatus { GOOD, BELOW_MINIMUM, LOSS }

data class BargainResult(
    val offerPaise: Long,
    val grossProfitPaise: Long,
    val discountFromSellingPaise: Long,
    val status: OfferStatus,
)

object BargainCalculator {
    /** Gross profit = customer offer − cost price. */
    fun evaluate(product: Product, offerPaise: Long): BargainResult {
        require(offerPaise >= 0) { "Offer cannot be negative" }
        val profit = offerPaise - product.costPaise
        val status = when {
            offerPaise < product.costPaise -> OfferStatus.LOSS
            offerPaise < product.minimumPaise -> OfferStatus.BELOW_MINIMUM
            else -> OfferStatus.GOOD
        }
        return BargainResult(offerPaise, profit, product.sellingPaise - offerPaise, status)
    }
}
