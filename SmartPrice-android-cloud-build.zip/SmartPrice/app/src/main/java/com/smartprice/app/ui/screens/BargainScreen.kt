package com.smartprice.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartprice.app.domain.BargainCalculator
import com.smartprice.app.domain.Money
import com.smartprice.app.domain.OfferStatus
import com.smartprice.app.ui.SmartPriceViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BargainScreen(vm: SmartPriceViewModel, initialId: String?, onBack: () -> Unit) {
    val products by vm.products.collectAsStateWithLifecycle()
    var selectedId by remember { mutableStateOf(initialId) }
    var expanded by remember { mutableStateOf(false) }
    var offer by remember { mutableStateOf("") }
    val product = products.firstOrNull { it.productId == selectedId }

    SpScaffold("Bargaining Calculator", onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (products.isEmpty()) { Text("Add a product first to use the calculator."); return@Column }
            ExposedDropdownMenuBox(expanded, { expanded = it }) {
                OutlinedTextField(product?.let { "${it.name} (${it.productId})" } ?: "", {}, readOnly = true,
                    label = { Text("Product") }, placeholder = { Text("Choose a product") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded, { expanded = false }) {
                    products.forEach { p ->
                        DropdownMenuItem(text = { Text("${p.name} (${p.productId})") }, onClick = { selectedId = p.productId; expanded = false })
                    }
                }
            }
            if (product != null) Text("Selling price ${Money.format(product.sellingPaise)} · Cost ${Money.format(product.costPaise)} · Minimum ${Money.format(product.minimumPaise)}",
                style = MaterialTheme.typography.bodySmall)

            val trimmed = offer.trim()
            val parsed = Money.parse(trimmed)
            val offerError = when {
                trimmed.isEmpty() -> null
                trimmed.startsWith("-") -> "Offer cannot be negative."
                parsed == null -> "Enter a valid amount like 450 or 450.50."
                else -> null
            }
            OutlinedTextField(offer, { offer = it.take(14) }, label = { Text("Customer offer (₹)") }, singleLine = true,
                isError = offerError != null, supportingText = { offerError?.let { Text(it) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())

            if (product != null && parsed != null && offerError == null) {
                val r = BargainCalculator.evaluate(product, parsed)
                ElevatedCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("Gross profit (offer − cost)", style = MaterialTheme.typography.bodyMedium)
                        Text(Money.format(r.grossProfitPaise), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold,
                            color = if (r.grossProfitPaise < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        if (r.discountFromSellingPaise > 0) Text("Discount from selling price: ${Money.format(r.discountFromSellingPaise)}")
                    }
                }
                when (r.status) {
                    OfferStatus.LOSS -> Banner("⛔ Offer is below cost price and below your minimum price (${Money.format(product.minimumPaise)}). You would lose money.",
                        MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.error)
                    OfferStatus.BELOW_MINIMUM -> Banner("⚠ Offer is below your minimum selling price of ${Money.format(product.minimumPaise)}.",
                        MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                    OfferStatus.GOOD -> Banner("✓ Offer is at or above your minimum price.",
                        MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                }
            } else if (product == null) Text("Choose a product to check an offer.")
        }
    }
}
