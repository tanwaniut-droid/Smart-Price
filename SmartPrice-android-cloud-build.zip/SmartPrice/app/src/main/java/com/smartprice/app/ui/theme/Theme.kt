package com.smartprice.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Emerald = Color(0xFF0F766E)
val EmeraldDark = Color(0xFF134E4A)
val Saffron = Color(0xFFF59E0B)
val Cream = Color(0xFFFBF8F1)
val Danger = Color(0xFFB91C1C)
val WarnBg = Color(0xFFFFF4D6)
val DangerBg = Color(0xFFFDE2E2)
val GoodBg = Color(0xFFDDF4EC)

private val scheme = lightColorScheme(
    primary = Emerald, onPrimary = Color.White,
    primaryContainer = GoodBg, onPrimaryContainer = EmeraldDark,
    secondary = Saffron, onSecondary = Color(0xFF3B2600),
    secondaryContainer = WarnBg, onSecondaryContainer = Color(0xFF5A3B00),
    background = Cream, surface = Color.White, onBackground = Color(0xFF1C1B17), onSurface = Color(0xFF1C1B17),
    error = Danger, errorContainer = DangerBg,
)

@Composable
fun SmartPriceTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
