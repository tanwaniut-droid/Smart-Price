package com.smartprice.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Money is stored in paise (1/100 rupee) as Long to avoid floating-point errors. */
@Entity(tableName = "products")
data class Product(
    @PrimaryKey val productId: String,
    val name: String,
    val costPaise: Long,
    val sellingPaise: Long,
    val minimumPaise: Long,
    val stock: Int,
    val updatedAt: Long = System.currentTimeMillis(),
)
