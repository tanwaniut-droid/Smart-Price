package com.smartprice.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE")
    fun observeAll(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE productId = :id LIMIT 1")
    suspend fun findById(id: String): Product?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(product: Product)

    @Update
    suspend fun update(product: Product): Int

    @Query("DELETE FROM products WHERE productId = :id")
    suspend fun delete(id: String)
}
