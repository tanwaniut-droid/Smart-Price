package com.smartprice.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.smartprice.app.data.Product
import com.smartprice.app.data.ProductRepository
import com.smartprice.app.domain.StockRules
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SmartPriceViewModel(private val repo: ProductRepository) : ViewModel() {
    val products: StateFlow<List<Product>> =
        repo.observeProducts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    suspend fun find(id: String) = repo.findById(id)
    suspend fun add(p: Product) = repo.add(p)
    suspend fun update(p: Product) = repo.update(p)
    fun delete(id: String) = viewModelScope.launch { repo.delete(id) }

    /** Returns an error message, or null on success. */
    suspend fun adjustStock(p: Product, delta: Int): String? {
        val next = StockRules.adjust(p.stock, delta) ?: return "Stock cannot go below 0."
        return repo.update(p.copy(stock = next)).exceptionOrNull()?.message
    }

    class Factory(private val repo: ProductRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = SmartPriceViewModel(repo) as T
    }
}
