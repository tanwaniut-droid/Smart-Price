package com.smartprice.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import androidx.activity.compose.rememberLauncherForActivityResult
import com.smartprice.app.domain.QrPayload
import com.smartprice.app.ui.SmartPriceViewModel
import kotlinx.coroutines.launch

@Composable
fun ScanScreen(vm: SmartPriceViewModel, onBack: () -> Unit, onFound: (String) -> Unit) {
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ScanContract()) { result ->
        val raw = result.contents
        if (raw == null) { message = "Scan cancelled."; return@rememberLauncherForActivityResult }
        val id = QrPayload.decode(raw)
        if (id == null) { message = "This QR code is not a SmartPrice product code."; return@rememberLauncherForActivityResult }
        scope.launch {
            if (vm.find(id) != null) onFound(id) else message = "No saved product with ID \"$id\"."
        }
    }
    fun start() {
        message = null
        launcher.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("Point the camera at a SmartPrice QR code").setBeepEnabled(false).setOrientationLocked(false))
    }
    LaunchedEffect(Unit) { start() }

    SpScaffold("Scan QR Code", onBack) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("The scanner asks for camera permission the first time. The QR code only holds the product ID.")
            message?.let { Banner(it, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer) }
            Button(onClick = ::start, Modifier.fillMaxWidth().height(52.dp)) { Text("Scan again") }
        }
    }
}
