# SmartPrice (demo) — Kotlin + Jetpack Compose

## Open & run
1. Open this folder in Android Studio (Koala or newer, JDK 17).
2. If asked, let Android Studio create the Gradle wrapper (Gradle 8.7+), then Sync.
3. Run on a phone or emulator (Android 7.0 / API 24+). The QR scanner needs a camera.
4. Unit tests: `./gradlew test` (rules in app/src/test).

## Features
Home · Add/Edit Product · Product list with search & delete · Bargaining calculator
(gross profit = offer − cost, warning below minimum price) · QR code per product
(contains ONLY `SMARTPRICE:<productId>`) · in-app QR scanner · Stock management with
low-stock warning (≤ 5 units).

## Privacy — read this
This is a local demonstration. Data is stored in a plain, unencrypted Room/SQLite
database on the phone. It is NOT secure storage, there is no login, and backup is disabled.

## Adding login / shared storage later
The UI only uses the `ProductRepository` interface (data/ProductRepository.kt).
Write a remote implementation (authenticated API) and swap it in `data/AppContainer.kt`.
Price/stock rules live in `domain/` and are independent of storage.
